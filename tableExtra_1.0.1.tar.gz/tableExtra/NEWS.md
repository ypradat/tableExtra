# tableExtra 1.0.1

## New features

- first release on CRAN
- the main function is `draw_table_extra()`. Examples of usage are provided in README, documentation and tests.
