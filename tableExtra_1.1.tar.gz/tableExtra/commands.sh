#!/bin/bash

# Exit immediately if a command fails
set -e

# --- User config ---
CONDA_ENV="r-viz"

# --- Script setup ---
# Find the directory where the script is located
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

# --- Define paths ---
NOTEBOOK_DIR="."
NOTEBOOK_IPYNB="${NOTEBOOK_DIR}/Untitled.ipynb"
NOTEBOOK_QMD="${NOTEBOOK_DIR}/Untitled.qmd"

OUTPUT_HTML="Untitled.html"

# --- Activate Conda Environment ---
# Ensure conda is initialized
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$CONDA_ENV"

echo ">>> Generating PCAWG Mutation Counts Overview Report"

# --- Convert .ipynb to .qmd for rendering ---
# Quarto can render .ipynb directly, but converting allows for easier modification if needed
echo ">>> Converting notebook to Quarto markdown format..."
quarto convert "${NOTEBOOK_IPYNB}"

sed -i '' '/^jupyter:/d' "${NOTEBOOK_QMD}"

# --- Render the notebook with Quarto ---
echo ">>> Rendering notebook with Quarto..."
quarto render "${NOTEBOOK_QMD}" --execute \
  --to html \
  --log-level DEBUG

# --- Move the rendered HTML to the final output directory ---
# The output HTML is created next to the .qmd file by default
mv "${NOTEBOOK_DIR}/Untitled.html" "${OUTPUT_HTML}"

echo ">>> ✅ Report saved successfully to: ${OUTPUT_HTML}"
