library(testthat)
library(tableExtra)

test_check("tableExtra")
